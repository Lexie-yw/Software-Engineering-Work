package com.work.service;

import com.work.entity.Reward;



public interface RewardService {
   Reward getReward();
}
